var mongourl = 'mongodb://localhost:27017/contactInfo';

module.exports = {
	url : mongourl
};
