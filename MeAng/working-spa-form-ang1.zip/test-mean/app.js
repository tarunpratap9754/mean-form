
var express  = require('express');
var app      = express(); 								
var port  	 = process.env.PORT || 9000; 
var mongoose = require('mongoose'); 							
var database = require('./config/database'); 			


var bodyParser = require('body-parser'); 	

try{
    mongoose.connect(database.url);
}catch (err)
{
    console.log(err);
}

app.use(express.static(__dirname + '/public')); 				
app.use(bodyParser.urlencoded({'extended':'true'})); 			
app.use(bodyParser.json()); 									
app.use(bodyParser.json({ type: 'application/vnd.api+json' })); 

// routes 
require('./app/routes.js')(app);


app.listen(port);
console.log("App listening on port " + port);
