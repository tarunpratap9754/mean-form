import { watch } from '../../utils';

/**
 * Executes the build process, watching for file changes and rebuilding the development environment.
 */
export = watch('build.dev');
