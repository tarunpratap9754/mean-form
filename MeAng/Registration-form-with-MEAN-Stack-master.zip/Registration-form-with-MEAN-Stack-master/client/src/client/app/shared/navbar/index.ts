/**
 * This barrel file provides the export for the shared NavbarComponent.
 */
export * from './navbar.component';
