export * from './registration.component';
export * from './registration.routes';
