import { Route } from '@angular/router';
import { RegistrationComponent } from './index';

export const RegistrationRoutes: Route[] = [
  {
    path: 'registration',
    component: RegistrationComponent
  }
];
