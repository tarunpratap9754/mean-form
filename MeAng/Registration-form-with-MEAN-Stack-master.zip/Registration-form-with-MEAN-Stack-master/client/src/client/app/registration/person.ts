export class Person {
	constructor(
    	public name: string,
    	public email: string,
    	public age: number
  	) { }
}