var mongoose = require('mongoose');

var Form = new mongoose.Schema({
    username :{
        firstname: String,
        lastname: String
    },
    contact: Number,
    email: String,
    address: {
        local: String,
        country: String,
        state: String,
        city: String,
        pin: Number
    }

});

mongoose.model('Form', Form);
mongoose.connect('mongodb://localhost/');