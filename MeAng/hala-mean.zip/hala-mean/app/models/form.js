require('mongoose').model('Form');

var mongoose = require('mongoose');
var Form = mongoose.model('Form');

module.exports = {
    
    createForms: function(req, res){
        var person = req.body;
        new Form({
            username: person.username,
            contact: person.contact,
            email: person.email,
            address: person.address
        }).save(function(err){
            if(err){
                res.status(504);
                res.end(err);
            } else{
                console.log('User saved');
                res.end();
            }
        });
    },

    seeResults: function (req, res, next) {
        Form.find({}, function (err, docs) {
          if (err) {
            res.status(504);
            res.end(err);
          } else {
            for (var i = 0; i < docs.length; i++) {
             console.log('user:', docs[i].name);
            }
            res.end(JSON.stringify(docs));
          }
        });
      },
      delete: function( req, res, next) {
        console.log(req.params.id);
        Form.find({ _id: req.params.id}, function(err) {
          if(err) {
            req.status(504);
            req.end();
            console.log(err);
          }
        }).remove(function (err) {
          console.log(err);
          if (err) {
            res.end(err);            
          } else {
            res.end();
          }
        });
      }
}