var express = require('express');

const bodyParser = require('body-parser');
var app = express();
var db = require('./config/db');
var user = require('./app/models/form');

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

app.use(express.static(__dirname + '/dist/hala'));

app.post('/users', user.createForms);
app.get('/users', user.seeResults);
app.delete('/users/:id', user.delete);


app.listen(3000, function(){
    console.log('App running');
});