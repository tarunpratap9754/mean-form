import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UsernameValidators } from './app.validators';
import { Person } from './person';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  form = new FormGroup({
    username: new FormGroup({
      firstname: new FormControl('Tester', [Validators.required, UsernameValidators.noSpace]),
      lastname: new FormControl('', [Validators.required, UsernameValidators.noSpace])
    }),
    contact: new FormControl('', [Validators.required, Validators.maxLength(10)]),
    email: new FormControl('you@tester.com', [Validators.email, Validators.required]),
    address: new FormGroup({
      local: new FormControl('', Validators.required),
      country: new FormControl('India', Validators.required),
      state: new FormControl('Tamil Nadu', Validators.required),
      city: new FormControl('Chennai', Validators.required),
      pin: new FormControl('', [Validators.required, Validators.pattern("[1-9][0-9]{5}")])
    })
  });

  onSubmit(){
    console.log(this.form.value);
  }
}

