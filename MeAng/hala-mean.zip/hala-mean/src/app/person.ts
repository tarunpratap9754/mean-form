export class Person {
    constructor(
        public username: string,
        public contact: Number,
        public email: string,
        public address: string
      ) { }
  }