# Angular-2-Tutorials
Docs pertaining to the tutorial series on Youtube.

Using the Template (Use Angular 2.2 Template)
- Clone to desktop.
- Navigate to the Template folder.
- Run 'npm install' on command line.
- Run 'npm start' on command line.
