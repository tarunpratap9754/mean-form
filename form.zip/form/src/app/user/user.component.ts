import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UsernameValidators } from '../app.validators';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  providers: [UserService]
})
export class UserComponent implements OnInit {

  constructor(private userService: UserService) { }

  users: User[];

  form = new FormGroup({
    firstname: new FormControl('Tester', [Validators.required, UsernameValidators.noSpace]),
    lastname: new FormControl('', [Validators.required, UsernameValidators.noSpace]),
    email: new FormControl('you@tester.com', [Validators.email, Validators.required])
  });

  addUser(){
    const newUser = {
      firstname : this.form.value.firstname,
      lastname : this.form.value.lastname,
      email : this.form.value.email
    };

    this.userService.addUser(newUser)
      .subscribe(user => {
        this.users.push(user);
      })
  }

  deleteUser(id: any) {
    var users = this.users;
    this.userService.deleteUser(id)
      .subscribe(data => {
        if (data.n == 1) {
          for (var i = 0; i < users.length; i++) {
            if (users[i]._id == id) {
              users.splice(i, 1);
            }
          }
        }
      });
  }

  ngOnInit() {
    this.userService.getUsers()
      .subscribe(users => this.users = users);
  }

}
