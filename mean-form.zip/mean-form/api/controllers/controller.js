var locationData = require('../data/locations.json');

module.exports.MainController = function(req, res){
    console.log('JSON route loaded');   
    console.log(req.query);

    var offset = 0;
    var count = 5;
    
    if(req.query && req.query.offset){
        offset = parseInt(req.query.offset, 10);
    }
    if(req.query && req.query.count){
        offset = parseInt(req.query.count, 10);
    }

    var returnData = locationData.slice(offset,offset+count);
        
    res
        .status(200)
        .json(returnData);
    };

module.exports.singleMainController = function(req, res){
    var jsonID = req.params.jsonid;
    var thisJson = locationData[jsonID];
    console.log('JSON route loaded for ', jsonID);   
        res
            .status(200)
            .json(thisJson);
    };