var express = require('express');
var router = express.Router();
var path = require('path');

var ctrlMain = require('../controllers/controller.js');

router
    .route('/json')
    .get(ctrlMain.MainController);

router
    .route('/json/:jsonid')
    .get(ctrlMain.singleMainController);

    module.exports = router;
    