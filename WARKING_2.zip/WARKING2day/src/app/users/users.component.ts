import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';
import { Country } from '../country';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UsernameValidators } from '../app.validators';
import { DropdownService } from '../dropdown.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  providers: [UserService, DropdownService]
})
export class UsersComponent implements OnInit {
  users: User[];
  user: User;

  countries: Country[];
  country: Country;

  states: Country[];
  state: Country;

  cName: string;

  selectedUser: User
  toggleForm: boolean = false

  constructor(private userService: UserService, private ddService: DropdownService) { }

  addUser(form) {
    const newUser: User = {
      firstname: form.value.firstname,
      lastname: form.value.lastname,
      email: form.value.email
    };

    this.userService.addUser(newUser)
      .subscribe(user => {
        this.users.push(user);
        this.userService.getUsers()
          .subscribe(users => this.users = users);
        form.reset();
      })
  }

  deleteUser(id: any) {
    var users = this.users;
    this.userService.deleteUser(id)
      .subscribe(data => {
        if (data.n == 1) {
          for (var i = 0; i < users.length; i++) {
            if (users[i]._id == id) {
              users.splice(i, 1);
            }
          }
        }
      })
  }

  updateUser(user) {
    if (!this.toggleForm) {
      this.selectedUser = user;
      this.toggleForm = !this.toggleForm;
    }
    else {
      this.toggleForm = !this.toggleForm;
    }

  }

  editUser(form) {
    let newUser: User = {
      _id: this.selectedUser._id,
      firstname: form.value.firstname,
      lastname: form.value.lastname,
      email: form.value.email
    };

    this.userService.updateUser(newUser)
      .subscribe(user => {
        this.userService.getUsers()
          .subscribe(users => this.users = users);
        this.toggleForm = !this.toggleForm;
      });


  }

  getStates(){
    this.ddService.getStates(this.cName)
      .subscribe(states => this.states = states);
  }

  ngOnInit() {
    this.userService.getUsers()
      .subscribe(users => this.users = users);

    this.ddService.getCountries()
      .subscribe(countries => this.countries = countries);
  }
}
