const express = require('express');
const router = express.Router();

const User = require('./models/user');

const Countries = require('./models/countries');


//GET
router.get('/users', function (req, res, next) {
    User.find(function (err, users) {
        res.json(users);
    })
});


//POST
router.post('/users', function (req, res, next) {

    newUser = new User({
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        email: req.body.email,
        country: req.body.country,
        state: req.body.state,
        city: req.body.city
    });

    newUser.save(function (err, user) {
        if (err) {
            res.json({ message: "Failed" });
        }
        else {
            res.json({ message: "Success" });
        }
    });
});

//PUT
router.put('/users/:id', function (req, res, next) {

    User.findOneAndUpdate({ _id: req.params.id },
        {
            $set: {
                firstname: req.body.firstname,
                lastname: req.body.lastname,
                email: req.body.email,
                country: req.body.country,
                state: req.body.state,
                city: req.body.city
            }
        },
        function (err, result) {
            if (err) {
                res.json({ message: "Failed" });
            }
            else {
                res.json({ message: "Success" });
            }
        });
});

//DELETE
router.delete('/users/:id', function (req, res, next) {
    User.remove({ _id: req.params.id }, function (err, result) {
        if (err) {
            res.json(err);
        }
        else {
            res.json(result);
        }
    });
});


//GET all data
router.get('/countries', function (req, res, next) {
    Countries.find(function (err, countries) {
        res.json(countries);
    })
});

//GET Country Names
router.get('/countries/all', function (req, res, next) {
    Countries.find({}, { "CountryName": 1, _id: 0 }, function (err, country) {
        res.json(country);
    })
});

//GET States
router.get('/countries/:cName', function (req, res, next) {
    Countries.aggregate([
        { $unwind: "$States" },
        { $match: { "CountryName": req.params.cName } },
        { $project: { "StateName": "$States.StateName", "_id": 0 } }
    ], function (err, states) {
        res.json(states);
    })
});

//GET Cities
router.get('/countries/:cName/:sName', function (req, res, next) {
    Countries.aggregate([
        { $unwind: "$States" },
        { $match: { "CountryName": req.params.cName, "States.StateName": req.params.sName } },
        { $project: { "Cities": "$States.Cities", "_id": 0 } },
        { $unwind: "$Cities" }
    ], function (err, states) {
        res.json(states);
    })
});


module.exports = router;