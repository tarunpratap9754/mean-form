export class User{
    _id?: string;
    firstname: string;
    lastname: string;
    email: string;
    country: string;
    state: string;
    city: string
}