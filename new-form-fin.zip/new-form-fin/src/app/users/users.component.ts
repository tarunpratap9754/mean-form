import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';
import { Country } from '../country';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UsernameValidators } from '../app.validators';
import { DropdownService } from '../dropdown.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  providers: [UserService, DropdownService]
})
export class UsersComponent implements OnInit {
  users: User[];
  user: User;

  countries: Country[];
  country: Country;

  states: Country[];
  state: Country;

  cities: Country["States"][];
  city: Country["States"];

  cName: string;
  sName: string;
  cityName: string;

  sDisabled: boolean = true;
  cDisabled: boolean = true;

  selectedUser: User
  toggleForm: boolean = false

  constructor(private userService: UserService, private ddService: DropdownService) { }

  addUser(form) {
    const newUser: User = {
      firstname: form.value.firstname,
      lastname: form.value.lastname,
      email: form.value.email,
      country: form.value.country,
      state: form.value.state,
      city: form.value.city
    };


    this.userService.addUser(newUser)
      .subscribe(user => {
        this.users.push(user);
        this.userService.getUsers()
          .subscribe(users => this.users = users);
        form.reset();
      })
  }

  deleteUser(user, id: any) {
    if (confirm("Are you sure to delete the entry for user " + user.firstname + "?")) {
      var users = this.users;
      this.userService.deleteUser(id)
        .subscribe(data => {
          if (data.n == 1) {
            for (var i = 0; i < users.length; i++) {
              if (users[i]._id == id) {
                users.splice(i, 1);
              }
            }
          }
        })
      if (this.toggleForm) {
        this.toggleForm = !this.toggleForm;
      }
    }
  }

  updateUser(user) {
    if (!this.toggleForm) {
      this.selectedUser = user;

      this.cName = user.country;
      this.sName = user.state;

      this.getStates();
      this.getCities();
      this.toggleForm = !this.toggleForm;
    }
    else {
      this.sDisabled = !this.sDisabled;
      this.cDisabled = !this.cDisabled;
      this.cName = "Country";
      this.sName = "State";
      this.toggleForm = !this.toggleForm;
    }

  }

  editUser(form) {
    let newUser: User = {
      _id: this.selectedUser._id,
      firstname: form.value.firstname,
      lastname: form.value.lastname,
      email: form.value.email,
      country: form.value.country,
      state: form.value.state,
      city: form.value.city
    };

    this.userService.updateUser(newUser)
      .subscribe(user => {
        this.userService.getUsers()
          .subscribe(users => this.users = users);
        form.reset();
        this.sDisabled = !this.sDisabled;
        this.cDisabled = !this.cDisabled;
        this.toggleForm = !this.toggleForm;
      });


  }

  getStates() {
    this.ddService.getStates(this.cName)
      .subscribe(states => this.states = states);
    if (this.toggleForm) {
      this.getCities();
    }
    if (!this.toggleForm) {
      this.sDisabled = false;
    }
  }

  getCities() {
    this.ddService.getCities(this.cName, this.sName)
      .subscribe(cities => this.cities = cities);
    if (!this.toggleForm) {
      this.cDisabled = false;
    }
  }

  ngOnInit() {
    this.userService.getUsers()
      .subscribe(users => this.users = users);

    this.ddService.getCountries()
      .subscribe(countries => this.countries = countries);
  }
}
